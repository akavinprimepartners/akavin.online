document.addEventListener('DOMContentLoaded', () => {

    const container = document.getElementById('akv-safe-panorama');

    if (!container) return;

    new PhotoSphereViewer.Viewer({
        container: container,
        panorama: AKAVIN_SAFE.image,
        navbar: ['zoom', 'fullscreen']
    });

});
